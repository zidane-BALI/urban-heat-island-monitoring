import requests
import json
from datetime import datetime
import time

DATABASE_URL = "https://communication-37968-default-rtdb.europe-west1.firebasedatabase.app"
OUTPUT_FILE = "data_machine.json"

last_saved_heure = None  # mémorise la dernière heure capteur sauvegardée

def get_data():
    url = f"{DATABASE_URL}/machine_1.json"
    try:
        response = requests.get(url, timeout=5)
        if response.status_code != 200:
            print("Erreur HTTP:", response.status_code)
            return None
        data = response.json()
        if data is None:
            return None
        return {
            "acceleration":       data.get("acceleration"),
            "delta_acceleration": data.get("delta_acceleration"),
            "etat_machine":       data.get("etat_machine"),
            "heure":              data.get("heure"),
            "hum_f":              data.get("hum_f"),
            "latitude":           data.get("latitude"),
            "longitude":          data.get("longitude"),
            "temp_f":             data.get("temp_f"),
            "quality_air":        data.get("qualite_air"),
            "timestamp_local":    datetime.now().isoformat()
        }
    except Exception as e:
        print("Erreur réseau:", e)
        return None

def save_json(new_data):
    try:
        try:
            with open(OUTPUT_FILE, "r") as f:
                history = json.load(f)
        except:
            history = []
        history.append(new_data)
        with open(OUTPUT_FILE, "w") as f:
            json.dump(history, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print("Erreur JSON:", e)

print("Lecture Firebase démarrée...")

while True:
    data = get_data()

    if data:
        # Ne sauvegarde que si l'heure capteur a changé (= nouvelle mesure)
        if data["heure"] != last_saved_heure:
            save_json(data)
            last_saved_heure = data["heure"]
            print(f"[{data['timestamp_local']}] Nouvelle mesure sauvegardée — heure: {data['heure']}")
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Pas de nouvelle mesure, on attend...")
    else:
        print("Aucune donnée")

