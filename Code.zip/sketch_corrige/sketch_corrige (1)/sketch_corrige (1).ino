#include<Wire.h>
#include<SPI.h>
#include<SD.h>
#include <TinyGPS++.h>
#include <Wire.h>
#include <Adafruit_LSM6DS3TRC.h>
#include <Adafruit_Sensor.h>
#include "esp_sleep.h"
#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "Redmi Note 13 Pro";
const char* password = "zizou2003";

// URL Firebase
const char* firebaseURL = "https://communication-37968-default-rtdb.europe-west1.firebasedatabase.app/machine_1.json";

//Pin d'interruption pour réveiller l'esp32
#define WAKEUP_PIN GPIO_NUM_27

//Intervalle de temps de mesure à l'arrêt
#define TEMPS_REPOS 300000000  // 5 minutes

//Intervalle de temps de mesure en roulant
int temps_debut_cycle;
int temps_actuel_cycle;

//Mode de fonctionnement (repos ou en route)
bool mode=1;

//Accéléromètre
Adafruit_LSM6DS3TRC lsm6ds3;
float acceleration;
float ancienne_acceleration;
float delta_acceleration;
float a_x;
float a_y;
float a_z;
int temps_debut;
int temps_fin;


const uint8_t adresse_temperature=0x45;

//pour récupérer la température et l'humidité
int compteur=0;
uint8_t MSB_temp;
uint8_t LSB_temp;
uint8_t MSB_hum;
uint8_t LSB_hum;

//Les CRC
uint8_t CRC_temp;
uint8_t CRC_hum;

//Valeur finale de la température et de l'humidité
uint16_t temperature;
uint16_t humidite;

//Chip Select pour la communication SPI de la carte SD
const int chipSelect=5;

//GPS
TinyGPSPlus gps;
HardwareSerial GPS(2);
float latitude;
float longitude;
float ancienne_longitude=0;
float ancienne_latitude=0;
float distance;
int heure;
int minute;
int seconde;

uint8_t calculCRC(uint8_t data[], uint8_t len);   // prototype déclaré avant setup()

void setup() {
  Serial.begin(9600);
  Wire.begin();
  SPI.begin();

  // Connexion WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connexion WiFi");
  int tentatives = 0;
  while (WiFi.status() != WL_CONNECTED && tentatives < 20) {
    delay(500);
    Serial.print(".");
    tentatives++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connecté !");
  } else {
    Serial.println("\nWiFi non connecté, données Firebase désactivées.");
  }

  //réveil de l'esp32
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();

  if (cause == ESP_SLEEP_WAKEUP_EXT0) {
    Serial.println("Réveil par mouvement !");
    mode=1;
  } 
  else if(cause==ESP_SLEEP_WAKEUP_TIMER){
    Serial.println("Reveil periodique (mode repos)");
    mode=0;
  }
  else {
    Serial.println("Démarrage normal");
    mode=1;
  }

  delay(5000);

  if (!lsm6ds3.begin_I2C()) {
    Serial.println("LSM6DS3 non detecte !");
    while (1) {
      delay(10);
    }
  }

  lsm6ds3.enableWakeup(true, 1, 5);

  lsm6ds3.configInt1(
    false,
    false,
    false,
    false,
    true
  );

  esp_sleep_enable_ext0_wakeup(WAKEUP_PIN, 1);
  esp_sleep_enable_timer_wakeup(TEMPS_REPOS);

  if(!SD.begin(chipSelect)){
    Serial.println("Erreur de transmission.");
    while(1);
  }

  GPS.begin(9600, SERIAL_8N1, 16, 17);

  temps_debut_cycle = millis() - 10000000;
}

void loop() {

  sensors_event_t accel;
  sensors_event_t gyro;
  sensors_event_t temp;

  lsm6ds3.getEvent(&accel, &gyro, &temp);

  a_x = accel.acceleration.x;
  a_y = accel.acceleration.y;
  a_z = accel.acceleration.z;

  acceleration = sqrt(sq(a_x) + sq(a_y) + sq(a_z));
  delta_acceleration = abs(acceleration - ancienne_acceleration);

  if(delta_acceleration < 0.1){
    temps_fin = millis();
    Serial.print("Temps avant extinction: ");
    Serial.print(30 - (temps_fin - temps_debut) / 1000);
    Serial.println(" secondes");
    if(temps_fin - temps_debut > 30000){
      Serial.println("Deep sleep");
      Serial.flush();
      esp_deep_sleep_start();
    }
  }
  else{
    temps_debut = millis();
  }

  ancienne_acceleration = acceleration;
  temps_actuel_cycle = millis();

  if(temps_actuel_cycle - temps_debut_cycle > 10000){
    temps_debut_cycle = millis();

    Wire.beginTransmission(adresse_temperature);
    Wire.write(0x2C);
    Wire.write(0x06);
    Wire.endTransmission();
    delay(20);

    const uint8_t nombreDonneesRecues = Wire.requestFrom(adresse_temperature, 6);
    while(Wire.available() > 0){
      uint8_t donneeRecue = Wire.read();
      if(compteur==0){
        MSB_temp = donneeRecue;
        compteur += 1;
      }
      else if(compteur==1){
        LSB_temp = donneeRecue;
        compteur += 1;
      }
      else if(compteur==2){
        CRC_temp = donneeRecue;
        compteur += 1;
      }
      else if(compteur==3){
        MSB_hum = donneeRecue;
        compteur += 1;
      }
      else if(compteur==4){
        LSB_hum = donneeRecue;
        compteur += 1;
      }
      else if(compteur==5){
        CRC_hum = donneeRecue;
        compteur += 1;
      }
    }

    uint8_t temp_data[2] = {MSB_temp, LSB_temp};
    uint8_t hum_data[2]  = {MSB_hum,  LSB_hum};

    if(calculCRC(temp_data, 2) == CRC_temp && calculCRC(hum_data, 2) == CRC_hum){

      // CORRECTION : cast et affectation corrects
      temperature = (uint16_t)(((uint16_t)MSB_temp << 8) | LSB_temp);
      humidite    = (uint16_t)(((uint16_t)MSB_hum  << 8) | LSB_hum);

      float temp_f = -45 + 175 * (temperature / 65535.0);
      float hum_f  = 100 * (humidite / 65535.0);

      Serial.print("Temperature: ");
      Serial.println(temp_f);
      Serial.print("Humidite: ");
      Serial.println(hum_f);

      while(GPS.available()) {
        gps.encode(GPS.read());
      }
      if (gps.location.isUpdated()) {
        latitude  = gps.location.lat();
        longitude = gps.location.lng();
        Serial.print("Latitude: ");
        Serial.println(latitude);
        Serial.print("Longitude: ");
        Serial.println(longitude);
      }

      if (gps.time.isUpdated()) {
        heure  = gps.time.hour() + 2;
        minute = gps.time.minute();
        seconde = gps.time.second();
        Serial.print("Heure: ");
        Serial.print(heure);
        Serial.print(":");
        Serial.print(minute);
        Serial.print(":");
        Serial.println(seconde);
      }

      File file = SD.open("/donnee_final.txt", FILE_APPEND);
      if(file){
        Serial.println("Données transmises.");
        file.print("Temperature: ");
        file.print(temp_f);
        file.print("  Humidité: ");
        file.print(hum_f);
        file.print(" Latitude: ");
        file.println(latitude);
        file.print(" Longitude: ");
        file.println(longitude);
        file.print(" Heure: ");
        file.print(heure);
        file.print(":");
        file.print(minute);
        file.print(":");
        file.println(seconde);
        file.close();
      }
    }
    else{
      Serial.println("Il y a eu une erreur de transmission.");
    }

    compteur = 0;
    delay(2000);

    if (WiFi.status() == WL_CONNECTED) {

      HTTPClient http;
      http.begin(firebaseURL);
      http.addHeader("Content-Type", "application/json");

      bool etat_machine = (delta_acceleration >= 0.01);

      String jsonData = "{";
      jsonData += "\"temp_f\":"         + String(temp_f)          + ",";
      jsonData += "\"hum_f\":"          + String(hum_f)           + ",";
      jsonData += "\"latitude\":"       + String(latitude, 6)     + ",";
      jsonData += "\"longitude\":"      + String(longitude, 6)    + ",";
      jsonData += "\"acceleration\":"   + String(acceleration)    + ",";
      jsonData += "\"delta_acceleration\":" + String(delta_acceleration) + ",";
      jsonData += "\"etat_machine\":"   + String(etat_machine)    + ",";
      jsonData += "\"heure\":\"" + String(heure) + ":" + String(minute) + ":" + String(seconde) + "\"";
      jsonData += "}";

      int code = http.PUT(jsonData);
      Serial.print("Firebase code: ");
      Serial.println(code);
      if (code > 0) {
        Serial.println(http.getString());
      }
      http.end();
    }

    delay(2000);
  }

  if(mode == 0){
    Serial.println("Deep sleep");
    Serial.flush();
    esp_deep_sleep_start();
  }
}

uint8_t calculCRC(uint8_t data[], uint8_t len){
  uint8_t crc = 0xFF;
  for(uint8_t i = 0; i < len; i++){
    crc ^= data[i];
    for(uint8_t bit = 0; bit < 8; bit++){
      if(crc & 0x80){
        crc = (crc << 1) ^ 0x31;
      }
      else{
        crc <<= 1;
      }
    }
  }
  return crc;
}
